﻿using System.Windows.Forms;

namespace System.Windows
{
    internal class FormsLabel : Label
    {
    }
}