﻿using System;
using System.Windows.Forms;
using System.Drawing;
using System.Text.RegularExpressions;

namespace StudentRegistrationApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {

            InitializeComponent();
        }


        // عند اختيار اللون
        private void Button1_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                label10.BackColor = colorDialog1.Color;
            }
        }

        // عند  التسجيل
        private void Button2_Click(object sender, EventArgs e)
        {
          
            string name = textBox1.Text.Trim();
            string email = textBox2.Text.Trim();
            string password = textBox3.Text.Trim();

            // التحقق من تعبئة الحقول
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please fill in all fields.", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // التحقق من صحة البريد الإلكتروني
            if (!IsValidEmail(email))
            {
                MessageBox.Show("Please enter a valid email address.", "Invalid Email", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // التحقق من تحديد الجنس
            string gender = "";
            if (radioButton1.Checked) gender = "Male";
            else if (radioButton2.Checked) gender = "Female";
            else if (radioButton3.Checked) gender = "Other";
            else gender = "Not Specified";  // إذا لم يتم تحديد أي خيار

            // التحقق من اختيار لون
            string favoriteColor = label10.BackColor.Name;  // لون الخلفية للـ Label10

            // التحقق من تحديد تاريخ الميلاد
            DateTime birthDate = dateTimePicker1.Value;

            // التحقق من تحديد بلد
            string country = "Not Selected";
            if (comboBox1.SelectedItem != null)
            {
                country = comboBox1.SelectedItem.ToString();
            }

          //عرض البيانات
            label8.Text = $"Name: {name}\nEmail: {email}\nGender: {gender}\nFavorite Color: {favoriteColor}\nBirth Date: {birthDate.ToShortDateString()}\nCountry: {country}";

           
        }



        private bool IsValidEmail(string email)
        {
            // التحقق من البريد الالكتروني
            if (string.IsNullOrWhiteSpace(email)) return false;

            
            string pattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";

            
            return Regex.IsMatch(email, pattern, RegexOptions.IgnoreCase);
        }


        // عند تحميل الفورم
        private void Form1_Load(object sender, EventArgs e)
        {
            this.BackColor = Color.LightBlue;
            comboBox1.Items.Add("Yemen");
            comboBox1.Items.Add("Saudi Arabia");
            comboBox1.Items.Add("Egypt");
            comboBox1.Items.Add("UAE");
            comboBox1.Items.Add("Jordan");

            comboBox1.SelectedIndex = 0;

            label10.Text = "       ";
            label10.BackColor = Color.Black;
            label10.ForeColor = Color.White;
        }


        private void Label10_Click(object sender, EventArgs e)
        {
        }
        

    }
}
